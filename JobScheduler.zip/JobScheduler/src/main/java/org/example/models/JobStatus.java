package org.example.models;

public enum JobStatus {
    RUNNING, FINISHED;

}
