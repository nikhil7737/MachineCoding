package org.example.models;

public class Capacity {

    public int cpu;
    public long ram;

    public Capacity(int cpu, long ram) {
        this.cpu = cpu;
        this.ram = ram;
    }

}
